package com.acme.kafkasdk.producer;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.SettableListenableFuture;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class KafkaProducerClientTest {

    @Test
    void sendSyncDelegatesToKafkaTemplate() throws Exception {
        KafkaTemplate<Object,Object> template = mock(KafkaTemplate.class);
        KafkaSdkProperties props = new KafkaSdkProperties();
        KafkaProducerClient client = new KafkaProducerClient(template, props);

        SettableListenableFuture<SendResult<Object,Object>> fut = new SettableListenableFuture<>();
        RecordMetadata md = new RecordMetadata(new TopicPartition("topic",0),0,5,1L,0L,0,0);
        fut.set(new SendResult<>(null, md));
        when(template.send("topic","k","v")).thenReturn(fut);

        RecordMetadata result = client.sendSync("topic","k","v");
        assertThat(result.offset()).isEqualTo(5);
        verify(template).send("topic","k","v");
    }
}
