package com.acme.kafkasdk.autoconfigure;

import com.acme.kafkasdk.producer.KafkaProducerClient;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import static org.assertj.core.api.Assertions.assertThat;

class KafkaSdkAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner =
        new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(KafkaSdkAutoConfiguration.class))
            .withPropertyValues(
                "kafka.sdk.bootstrap-servers=localhost:9093",
                "kafka.sdk.security.protocol=SSL",
                "kafka.sdk.ssl.key-store-location=/tmp/keystore.p12",
                "kafka.sdk.ssl.key-store-password=secret",
                "kafka.sdk.ssl.trust-store-location=/tmp/truststore.p12",
                "kafka.sdk.ssl.trust-store-password=secret"
            );

    @Test
    void autoConfigRegistersBeans() {
        contextRunner.run(ctx -> {
            assertThat(ctx).hasSingleBean(KafkaProducerClient.class);
            assertThat(ctx).hasSingleBean(org.springframework.kafka.core.KafkaTemplate.class);
        });
    }
}
