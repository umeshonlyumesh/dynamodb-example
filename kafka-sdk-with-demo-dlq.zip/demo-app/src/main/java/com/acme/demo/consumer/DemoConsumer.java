package com.acme.demo.consumer;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
@Component
public class DemoConsumer {
  @KafkaListener(topics="demo-topic")
  public void onMessage(Object event){
    System.out.println("Received:"+event);
  }
}
