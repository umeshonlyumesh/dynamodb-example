package com.acme.kafkasdk.producer;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;

@Slf4j
@RequiredArgsConstructor
public class KafkaProducerClient {
    private final KafkaTemplate<Object,Object> template;
    private final KafkaSdkProperties props;

    public ListenableFuture<SendResult<Object,Object>> sendAsync(String topic, Object key, Object value, String dlqTopic) {
        ListenableFuture<SendResult<Object,Object>> future = template.send(topic, key, value);
        future.addCallback(
            result -> log.info("Async OK topic={} offset={}", result.getRecordMetadata().topic(), result.getRecordMetadata().offset()),
            ex -> { log.error("Async send failed {}", ex.toString()); publishToDlq(dlqTopic,key,value); });
        return future;
    }

    public RecordMetadata sendSync(String topic,Object key,Object value,String dlqTopic) throws Exception {
        try {
            SendResult<Object,Object> res=template.send(topic,key,value).get();
            return res.getRecordMetadata();
        } catch(Exception ex) {
            log.error("Sync send failed {}",ex.toString());
            publishToDlq(dlqTopic,key,value);
            throw ex;
        }
    }

    private void publishToDlq(String dlqTopic,Object key,Object value) {
        String target=dlqTopic!=null?dlqTopic:props.getProducer().getDefaultDlqTopic();
        if(target==null){log.warn("No DLQ configured"); return;}
        try {
            template.send(target,key,value);
            log.info("Published to DLQ {}",target);
        }catch(Exception e){log.error("Failed to publish to DLQ {}",target);}
    }
}
