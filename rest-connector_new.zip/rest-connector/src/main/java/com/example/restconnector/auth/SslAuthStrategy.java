package com.example.restconnector.auth;

import com.example.restconnector.model.RestRequest;
import com.example.restconnector.ssl.SslContextFactory;
import lombok.Getter;

import javax.net.ssl.SSLContext;

/**
 * Authentication strategy for SSL/TLS connections.
 * This strategy configures SSL/TLS settings for secure connections.
 */
public class SslAuthStrategy implements AuthenticationStrategy {

    @Getter
    private final SSLContext sslContext;
    private final boolean verifyHostname;

    /**
     * Creates a new SslAuthStrategy with the specified SSL context and hostname verification setting.
     *
     * @param sslContext The SSL context to use
     * @param verifyHostname Whether to verify hostnames in server certificates
     */
    public SslAuthStrategy(SSLContext sslContext, boolean verifyHostname) {
        this.sslContext = sslContext;
        this.verifyHostname = verifyHostname;
    }

    /**
     * Creates a new SslAuthStrategy with the specified SSL configuration.
     *
     * @param config The SSL configuration
     */
    public SslAuthStrategy(SslContextFactory.SslConfig config) {
        this.sslContext = SslContextFactory.createSslContext(config);
        this.verifyHostname = config.isVerifyHostname();
    }

    /**
     * Returns the request without modifying it.
     * The SSL context is used by the connector implementation when establishing the connection.
     *
     * @param request The request to authenticate
     * @return The same request without modifications
     */
    @Override
    public RestRequest authenticate(RestRequest request) {
        // SSL authentication happens at the connection level, not in the request
        return request;
    }

    /**
     * Gets the name of this authentication strategy.
     *
     * @return "SSL"
     */
    @Override
    public String getName() {
        return "SSL";
    }

    /**
     * Checks if this authentication strategy requires SSL/TLS.
     *
     * @return true, as this is an SSL/TLS authentication strategy
     */
    @Override
    public boolean requiresSecureConnection() {
        return true;
    }

    /**
     * Gets whether to verify hostnames in server certificates.
     *
     * @return true if hostnames should be verified, false otherwise
     */
    public boolean isVerifyHostname() {
        return verifyHostname;
    }
}