package com.example.restconnector.ssl;

import com.example.restconnector.RestConnectorException;
import lombok.Builder;
import lombok.Getter;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

/**
 * Factory for creating SSL contexts with various configurations.
 * Supports client certificates (mTLS), custom trust stores, and other SSL/TLS options.
 */
public class SslContextFactory {

    /**
     * Creates an SSL context with the specified configuration.
     *
     * @param config The SSL configuration
     * @return The configured SSL context
     * @throws RestConnectorException if an error occurs during SSL context creation
     */
    public static SSLContext createSslContext(SslConfig config) {
        try {
            SSLContext sslContext = SSLContext.getInstance(config.getProtocol());
            
            KeyManager[] keyManagers = null;
            if (config.getKeyStorePath() != null) {
                keyManagers = createKeyManagers(
                        config.getKeyStorePath(),
                        config.getKeyStorePassword(),
                        config.getKeyStoreType(),
                        config.getKeyPassword()
                );
            }
            
            TrustManager[] trustManagers = null;
            if (config.getTrustStorePath() != null) {
                trustManagers = createTrustManagers(
                        config.getTrustStorePath(),
                        config.getTrustStorePassword(),
                        config.getTrustStoreType()
                );
            }
            
            sslContext.init(keyManagers, trustManagers, new SecureRandom());
            return sslContext;
            
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            throw new RestConnectorException("Failed to create SSL context", e);
        }
    }
    
    /**
     * Creates key managers for client authentication (mTLS).
     */
    private static KeyManager[] createKeyManagers(String keyStorePath, String keyStorePassword, 
                                                 String keyStoreType, String keyPassword) {
        try {
            KeyStore keyStore = KeyStore.getInstance(keyStoreType);
            try (InputStream is = new FileInputStream(keyStorePath)) {
                keyStore.load(is, keyStorePassword.toCharArray());
            }
            
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(keyStore, (keyPassword != null ? keyPassword : keyStorePassword).toCharArray());
            return kmf.getKeyManagers();
            
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException | 
                 CertificateException | IOException e) {
            throw new RestConnectorException("Failed to create key managers", e);
        }
    }
    
    /**
     * Creates trust managers for server certificate validation.
     */
    private static TrustManager[] createTrustManagers(String trustStorePath, String trustStorePassword, 
                                                     String trustStoreType) {
        try {
            KeyStore trustStore = KeyStore.getInstance(trustStoreType);
            try (InputStream is = new FileInputStream(trustStorePath)) {
                trustStore.load(is, trustStorePassword.toCharArray());
            }
            
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(trustStore);
            return tmf.getTrustManagers();
            
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e) {
            throw new RestConnectorException("Failed to create trust managers", e);
        }
    }
    
    /**
     * Configuration for SSL/TLS connections.
     */
    @Getter
    @Builder
    public static class SslConfig {
        /**
         * The SSL/TLS protocol to use (e.g., "TLS", "TLSv1.2").
         */
        @Builder.Default
        private final String protocol = "TLS";
        
        /**
         * Path to the key store file for client authentication (mTLS).
         */
        private final String keyStorePath;
        
        /**
         * Password for the key store.
         */
        private final String keyStorePassword;
        
        /**
         * Type of the key store (e.g., "JKS", "PKCS12").
         */
        @Builder.Default
        private final String keyStoreType = "PKCS12";
        
        /**
         * Password for the key (if different from the key store password).
         */
        private final String keyPassword;
        
        /**
         * Path to the trust store file for server certificate validation.
         */
        private final String trustStorePath;
        
        /**
         * Password for the trust store.
         */
        private final String trustStorePassword;
        
        /**
         * Type of the trust store (e.g., "JKS", "PKCS12").
         */
        @Builder.Default
        private final String trustStoreType = "JKS";
        
        /**
         * Whether to verify hostnames in server certificates.
         */
        @Builder.Default
        private final boolean verifyHostname = true;
    }
}