package com.example.restconnector.auth;

import com.example.restconnector.model.RestRequest;
import lombok.Getter;

import javax.net.ssl.SSLContext;
import java.util.Arrays;
import java.util.List;

/**
 * Authentication strategy that combines multiple authentication strategies.
 * This allows for combining SSL/TLS configuration with other authentication methods.
 */
public class CompositeAuthStrategy implements AuthenticationStrategy {

    private final List<AuthenticationStrategy> strategies;
    
    @Getter
    private final SSLContext sslContext;
    
    @Getter
    private final boolean verifyHostname;

    /**
     * Creates a new CompositeAuthStrategy with the specified authentication strategies.
     *
     * @param strategies The authentication strategies to combine
     */
    public CompositeAuthStrategy(AuthenticationStrategy... strategies) {
        this.strategies = Arrays.asList(strategies);
        
        // Extract SSL context and hostname verification setting from SslAuthStrategy if present
        SslAuthStrategy sslStrategy = findSslStrategy();
        this.sslContext = sslStrategy != null ? sslStrategy.getSslContext() : null;
        this.verifyHostname = sslStrategy != null ? sslStrategy.isVerifyHostname() : true;
    }

    /**
     * Applies all authentication strategies to the request in the order they were provided.
     *
     * @param request The request to authenticate
     * @return The authenticated request
     */
    @Override
    public RestRequest authenticate(RestRequest request) {
        RestRequest authenticatedRequest = request;
        for (AuthenticationStrategy strategy : strategies) {
            authenticatedRequest = strategy.authenticate(authenticatedRequest);
        }
        return authenticatedRequest;
    }

    /**
     * Gets the name of this authentication strategy.
     *
     * @return A combined name of all strategies
     */
    @Override
    public String getName() {
        StringBuilder name = new StringBuilder("Composite(");
        for (int i = 0; i < strategies.size(); i++) {
            if (i > 0) {
                name.append("+");
            }
            name.append(strategies.get(i).getName());
        }
        name.append(")");
        return name.toString();
    }

    /**
     * Checks if any of the authentication strategies requires SSL/TLS.
     *
     * @return true if any strategy requires a secure connection, false otherwise
     */
    @Override
    public boolean requiresSecureConnection() {
        for (AuthenticationStrategy strategy : strategies) {
            if (strategy.requiresSecureConnection()) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Finds the SslAuthStrategy in the list of strategies, if any.
     *
     * @return The SslAuthStrategy, or null if none is present
     */
    private SslAuthStrategy findSslStrategy() {
        for (AuthenticationStrategy strategy : strategies) {
            if (strategy instanceof SslAuthStrategy) {
                return (SslAuthStrategy) strategy;
            }
        }
        return null;
    }
    
    /**
     * Checks if this strategy has SSL configuration.
     *
     * @return true if this strategy has SSL configuration, false otherwise
     */
    public boolean hasSslConfiguration() {
        return sslContext != null;
    }
}