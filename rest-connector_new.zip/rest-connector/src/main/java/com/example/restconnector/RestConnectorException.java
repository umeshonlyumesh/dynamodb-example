package com.example.restconnector;

/**
 * Exception thrown by RestConnector implementations when an error occurs during a REST API call.
 */
public class RestConnectorException extends RuntimeException {

    /**
     * HTTP status code associated with this exception, if applicable.
     */
    private final int statusCode;

    /**
     * Creates a new RestConnectorException with the specified message.
     *
     * @param message The error message
     */
    public RestConnectorException(String message) {
        super(message);
        this.statusCode = 0;
    }

    /**
     * Creates a new RestConnectorException with the specified message and cause.
     *
     * @param message The error message
     * @param cause The cause of the exception
     */
    public RestConnectorException(String message, Throwable cause) {
        super(message, cause);
        this.statusCode = 0;
    }

    /**
     * Creates a new RestConnectorException with the specified message and HTTP status code.
     *
     * @param message The error message
     * @param statusCode The HTTP status code
     */
    public RestConnectorException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }

    /**
     * Creates a new RestConnectorException with the specified message, cause, and HTTP status code.
     *
     * @param message The error message
     * @param cause The cause of the exception
     * @param statusCode The HTTP status code
     */
    public RestConnectorException(String message, Throwable cause, int statusCode) {
        super(message, cause);
        this.statusCode = statusCode;
    }

    /**
     * Gets the HTTP status code associated with this exception.
     *
     * @return The HTTP status code, or 0 if not applicable
     */
    public int getStatusCode() {
        return statusCode;
    }
}