package com.example.restconnector.auth;

import com.example.restconnector.RestConnectorException;
import com.example.restconnector.model.RestRequest;
import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.Collections;

/**
 * Authentication strategy for OAuth 2.0 authentication.
 * Supports client credentials and password grant types.
 */
@Slf4j
public class OAuth2Strategy implements AuthenticationStrategy {

    private final OAuth2Config config;
    private final RestTemplate restTemplate;
    
    private String accessToken;
    private Instant tokenExpiration;

    /**
     * Creates a new OAuth2Strategy with the specified configuration.
     *
     * @param config The OAuth2 configuration
     */
    public OAuth2Strategy(OAuth2Config config) {
        this.config = config;
        this.restTemplate = new RestTemplate();
    }

    /**
     * Applies OAuth 2.0 authentication to the request by adding an Authorization header with the access token.
     * If the token is expired or not yet obtained, it will be requested first.
     *
     * @param request The request to authenticate
     * @return The authenticated request with the Authorization header
     * @throws RestConnectorException if token acquisition fails
     */
    @Override
    public RestRequest authenticate(RestRequest request) {
        ensureValidToken();
        request.addHeader("Authorization", "Bearer " + accessToken);
        return request;
    }

    /**
     * Gets the name of this authentication strategy.
     *
     * @return "OAuth2"
     */
    @Override
    public String getName() {
        return "OAuth2";
    }

    /**
     * Checks if this authentication strategy requires SSL/TLS.
     *
     * @return true, as OAuth 2.0 should always use a secure connection
     */
    @Override
    public boolean requiresSecureConnection() {
        return true;
    }

    /**
     * Ensures that a valid token is available, requesting a new one if necessary.
     *
     * @throws RestConnectorException if token acquisition fails
     */
    private synchronized void ensureValidToken() {
        if (accessToken == null || tokenExpiration == null || Instant.now().isAfter(tokenExpiration)) {
            requestNewToken();
        }
    }

    /**
     * Requests a new access token from the OAuth 2.0 server.
     *
     * @throws RestConnectorException if token acquisition fails
     */
    private void requestNewToken() {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            
            MultiValueMap<String, String> formParams = new LinkedMultiValueMap<>();
            formParams.add("grant_type", config.getGrantType());
            
            if ("client_credentials".equals(config.getGrantType())) {
                headers.setBasicAuth(config.getClientId(), config.getClientSecret());
            } else if ("password".equals(config.getGrantType())) {
                formParams.add("client_id", config.getClientId());
                formParams.add("client_secret", config.getClientSecret());
                formParams.add("username", config.getUsername());
                formParams.add("password", config.getPassword());
            } else {
                throw new RestConnectorException("Unsupported grant type: " + config.getGrantType());
            }
            
            if (config.getScope() != null && !config.getScope().isEmpty()) {
                formParams.add("scope", config.getScope());
            }
            
            HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(formParams, headers);
            
            ResponseEntity<TokenResponse> response = restTemplate.postForEntity(
                    config.getTokenUrl(), entity, TokenResponse.class);
            
            if (response.getBody() == null) {
                throw new RestConnectorException("Empty response from OAuth server");
            }
            
            TokenResponse tokenResponse = response.getBody();
            accessToken = tokenResponse.getAccessToken();
            
            if (tokenResponse.getExpiresIn() > 0) {
                // Set expiration to slightly before the actual expiration to account for network latency
                tokenExpiration = Instant.now().plusSeconds(tokenResponse.getExpiresIn() - 60);
            } else {
                // If no expiration is provided, set a default of 1 hour
                tokenExpiration = Instant.now().plusSeconds(3600 - 60);
            }
            
            log.debug("OAuth2 token acquired, expires at: {}", tokenExpiration);
            
        } catch (Exception e) {
            throw new RestConnectorException("Failed to acquire OAuth2 token", e);
        }
    }

    /**
     * Configuration for OAuth 2.0 authentication.
     */
    @Getter
    @Builder
    public static class OAuth2Config {
        private final String tokenUrl;
        private final String clientId;
        private final String clientSecret;
        private final String grantType;
        private final String username;
        private final String password;
        private final String scope;
    }

    /**
     * Response from the OAuth 2.0 token endpoint.
     */
    @Getter
    private static class TokenResponse {
        private String accessToken;
        private String tokenType;
        private int expiresIn;
        private String refreshToken;
        private String scope;
    }
}