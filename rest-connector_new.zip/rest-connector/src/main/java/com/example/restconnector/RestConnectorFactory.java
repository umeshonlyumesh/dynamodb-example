package com.example.restconnector;

import com.example.restconnector.auth.AuthenticationStrategy;
import com.example.restconnector.auth.BasicAuthStrategy;
import com.example.restconnector.auth.CompositeAuthStrategy;
import com.example.restconnector.auth.NoAuthStrategy;
import com.example.restconnector.auth.OAuth2Strategy;
import com.example.restconnector.auth.SslAuthStrategy;
import com.example.restconnector.impl.RestClientConnector;
import com.example.restconnector.ssl.SslContextFactory;

import javax.net.ssl.SSLContext;
import java.util.concurrent.Executor;

/**
 * Factory for creating RestConnector instances with various configurations.
 */
public class RestConnectorFactory {

    /**
     * Creates a RestConnector with no authentication.
     *
     * @return A new RestConnector instance
     */
    public static RestConnector createNoAuthConnector() {
        return new RestClientConnector(new NoAuthStrategy());
    }

    /**
     * Creates a RestConnector with basic authentication.
     *
     * @param username The username for authentication
     * @param password The password for authentication
     * @return A new RestConnector instance
     */
    public static RestConnector createBasicAuthConnector(String username, String password) {
        return new RestClientConnector(new BasicAuthStrategy(username, password));
    }

    /**
     * Creates a RestConnector with basic authentication and configurable secure connection requirement.
     *
     * @param username The username for authentication
     * @param password The password for authentication
     * @param requiresSecureConnection Whether a secure connection is required
     * @return A new RestConnector instance
     */
    public static RestConnector createBasicAuthConnector(String username, String password, boolean requiresSecureConnection) {
        return new RestClientConnector(new BasicAuthStrategy(username, password, requiresSecureConnection));
    }

    /**
     * Creates a RestConnector with OAuth 2.0 client credentials authentication.
     *
     * @param tokenUrl The URL of the OAuth 2.0 token endpoint
     * @param clientId The client ID
     * @param clientSecret The client secret
     * @return A new RestConnector instance
     */
    public static RestConnector createOAuth2ClientCredentialsConnector(String tokenUrl, String clientId, String clientSecret) {
        OAuth2Strategy.OAuth2Config config = OAuth2Strategy.OAuth2Config.builder()
                .tokenUrl(tokenUrl)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .grantType("client_credentials")
                .build();

        return new RestClientConnector(new OAuth2Strategy(config));
    }

    /**
     * Creates a RestConnector with OAuth 2.0 password authentication.
     *
     * @param tokenUrl The URL of the OAuth 2.0 token endpoint
     * @param clientId The client ID
     * @param clientSecret The client secret
     * @param username The username
     * @param password The password
     * @return A new RestConnector instance
     */
    public static RestConnector createOAuth2PasswordConnector(String tokenUrl, String clientId, String clientSecret,
                                                            String username, String password) {
        OAuth2Strategy.OAuth2Config config = OAuth2Strategy.OAuth2Config.builder()
                .tokenUrl(tokenUrl)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .grantType("password")
                .username(username)
                .password(password)
                .build();

        return new RestClientConnector(new OAuth2Strategy(config));
    }

    /**
     * Creates a RestConnector with SSL/TLS authentication.
     *
     * @param sslContext The SSL context to use
     * @param verifyHostname Whether to verify hostnames in server certificates
     * @return A new RestConnector instance
     */
    public static RestConnector createSslConnector(SSLContext sslContext, boolean verifyHostname) {
        return new RestClientConnector(new SslAuthStrategy(sslContext, verifyHostname));
    }

    /**
     * Creates a RestConnector with SSL/TLS authentication using a key store and trust store.
     *
     * @param keyStorePath The path to the key store file
     * @param keyStorePassword The password for the key store
     * @param trustStorePath The path to the trust store file
     * @param trustStorePassword The password for the trust store
     * @return A new RestConnector instance
     */
    public static RestConnector createMtlsConnector(String keyStorePath, String keyStorePassword,
                                                  String trustStorePath, String trustStorePassword) {
        SslContextFactory.SslConfig config = SslContextFactory.SslConfig.builder()
                .keyStorePath(keyStorePath)
                .keyStorePassword(keyStorePassword)
                .trustStorePath(trustStorePath)
                .trustStorePassword(trustStorePassword)
                .build();

        return new RestClientConnector(new SslAuthStrategy(config));
    }

    /**
     * Creates a RestConnector with a custom authentication strategy.
     *
     * @param authStrategy The authentication strategy to use
     * @return A new RestConnector instance
     */
    public static RestConnector createConnector(AuthenticationStrategy authStrategy) {
        return new RestClientConnector(authStrategy);
    }

    /**
     * Creates a RestConnector with a custom authentication strategy and executor.
     *
     * @param authStrategy The authentication strategy to use
     * @param executor The executor for asynchronous operations
     * @return A new RestConnector instance
     */
    public static RestConnector createConnector(AuthenticationStrategy authStrategy, Executor executor) {
        return new RestClientConnector(authStrategy, executor);
    }

    /**
     * Creates a RestConnector with basic authentication and mTLS.
     *
     * @param username The username for authentication
     * @param password The password for authentication
     * @param keyStorePath The path to the key store file
     * @param keyStorePassword The password for the key store
     * @param trustStorePath The path to the trust store file
     * @param trustStorePassword The password for the trust store
     * @return A new RestConnector instance
     */
    public static RestConnector createBasicAuthWithMtlsConnector(String username, String password,
                                                               String keyStorePath, String keyStorePassword,
                                                               String trustStorePath, String trustStorePassword) {
        BasicAuthStrategy basicAuthStrategy = new BasicAuthStrategy(username, password);

        SslContextFactory.SslConfig sslConfig = SslContextFactory.SslConfig.builder()
                .keyStorePath(keyStorePath)
                .keyStorePassword(keyStorePassword)
                .trustStorePath(trustStorePath)
                .trustStorePassword(trustStorePassword)
                .build();

        SslAuthStrategy sslAuthStrategy = new SslAuthStrategy(sslConfig);

        CompositeAuthStrategy compositeAuthStrategy = new CompositeAuthStrategy(basicAuthStrategy, sslAuthStrategy);

        return new RestClientConnector(compositeAuthStrategy);
    }

    /**
     * Creates a RestConnector with no authentication but with mTLS.
     *
     * @param keyStorePath The path to the key store file
     * @param keyStorePassword The password for the key store
     * @param trustStorePath The path to the trust store file
     * @param trustStorePassword The password for the trust store
     * @return A new RestConnector instance
     */
    public static RestConnector createNoAuthWithMtlsConnector(String keyStorePath, String keyStorePassword,
                                                            String trustStorePath, String trustStorePassword) {
        NoAuthStrategy noAuthStrategy = new NoAuthStrategy();

        SslContextFactory.SslConfig sslConfig = SslContextFactory.SslConfig.builder()
                .keyStorePath(keyStorePath)
                .keyStorePassword(keyStorePassword)
                .trustStorePath(trustStorePath)
                .trustStorePassword(trustStorePassword)
                .build();

        SslAuthStrategy sslAuthStrategy = new SslAuthStrategy(sslConfig);

        CompositeAuthStrategy compositeAuthStrategy = new CompositeAuthStrategy(noAuthStrategy, sslAuthStrategy);

        return new RestClientConnector(compositeAuthStrategy);
    }

    /**
     * Creates a RestConnector with OAuth 2.0 client credentials authentication and mTLS.
     *
     * @param tokenUrl The URL of the OAuth 2.0 token endpoint
     * @param clientId The client ID
     * @param clientSecret The client secret
     * @param keyStorePath The path to the key store file
     * @param keyStorePassword The password for the key store
     * @param trustStorePath The path to the trust store file
     * @param trustStorePassword The password for the trust store
     * @return A new RestConnector instance
     */
    public static RestConnector createOAuth2ClientCredentialsWithMtlsConnector(
            String tokenUrl, String clientId, String clientSecret,
            String keyStorePath, String keyStorePassword,
            String trustStorePath, String trustStorePassword) {

        OAuth2Strategy.OAuth2Config oauthConfig = OAuth2Strategy.OAuth2Config.builder()
                .tokenUrl(tokenUrl)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .grantType("client_credentials")
                .build();

        OAuth2Strategy oauthStrategy = new OAuth2Strategy(oauthConfig);

        SslContextFactory.SslConfig sslConfig = SslContextFactory.SslConfig.builder()
                .keyStorePath(keyStorePath)
                .keyStorePassword(keyStorePassword)
                .trustStorePath(trustStorePath)
                .trustStorePassword(trustStorePassword)
                .build();

        SslAuthStrategy sslAuthStrategy = new SslAuthStrategy(sslConfig);

        CompositeAuthStrategy compositeAuthStrategy = new CompositeAuthStrategy(oauthStrategy, sslAuthStrategy);

        return new RestClientConnector(compositeAuthStrategy);
    }

    /**
     * Creates a RestConnector with OAuth 2.0 password authentication and mTLS.
     *
     * @param tokenUrl The URL of the OAuth 2.0 token endpoint
     * @param clientId The client ID
     * @param clientSecret The client secret
     * @param username The username
     * @param password The password
     * @param keyStorePath The path to the key store file
     * @param keyStorePassword The password for the key store
     * @param trustStorePath The path to the trust store file
     * @param trustStorePassword The password for the trust store
     * @return A new RestConnector instance
     */
    public static RestConnector createOAuth2PasswordWithMtlsConnector(
            String tokenUrl, String clientId, String clientSecret,
            String username, String password,
            String keyStorePath, String keyStorePassword,
            String trustStorePath, String trustStorePassword) {

        OAuth2Strategy.OAuth2Config oauthConfig = OAuth2Strategy.OAuth2Config.builder()
                .tokenUrl(tokenUrl)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .grantType("password")
                .username(username)
                .password(password)
                .build();

        OAuth2Strategy oauthStrategy = new OAuth2Strategy(oauthConfig);

        SslContextFactory.SslConfig sslConfig = SslContextFactory.SslConfig.builder()
                .keyStorePath(keyStorePath)
                .keyStorePassword(keyStorePassword)
                .trustStorePath(trustStorePath)
                .trustStorePassword(trustStorePassword)
                .build();

        SslAuthStrategy sslAuthStrategy = new SslAuthStrategy(sslConfig);

        CompositeAuthStrategy compositeAuthStrategy = new CompositeAuthStrategy(oauthStrategy, sslAuthStrategy);

        return new RestClientConnector(compositeAuthStrategy);
    }
}
