package com.example.restconnector.auth;

import com.example.restconnector.model.RestRequest;

import java.util.Base64;

/**
 * Authentication strategy for HTTP Basic Authentication.
 * Adds an Authorization header with the Base64-encoded username and password.
 */
public class BasicAuthStrategy implements AuthenticationStrategy {

    private final String username;
    private final String password;
    private final boolean requiresSecureConnection;

    /**
     * Creates a new BasicAuthStrategy with the specified username and password.
     * By default, requires a secure connection.
     *
     * @param username The username for authentication
     * @param password The password for authentication
     */
    public BasicAuthStrategy(String username, String password) {
        this(username, password, true);
    }

    /**
     * Creates a new BasicAuthStrategy with the specified username, password, and secure connection requirement.
     *
     * @param username The username for authentication
     * @param password The password for authentication
     * @param requiresSecureConnection Whether a secure connection is required
     */
    public BasicAuthStrategy(String username, String password, boolean requiresSecureConnection) {
        this.username = username;
        this.password = password;
        this.requiresSecureConnection = requiresSecureConnection;
    }

    /**
     * Applies Basic Authentication to the request by adding an Authorization header.
     *
     * @param request The request to authenticate
     * @return The authenticated request with the Authorization header
     */
    @Override
    public RestRequest authenticate(RestRequest request) {
        String auth = username + ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
        String authHeader = "Basic " + encodedAuth;
        
        request.addHeader("Authorization", authHeader);
        return request;
    }

    /**
     * Gets the name of this authentication strategy.
     *
     * @return "BasicAuth"
     */
    @Override
    public String getName() {
        return "BasicAuth";
    }

    /**
     * Checks if this authentication strategy requires SSL/TLS.
     *
     * @return true if a secure connection is required, false otherwise
     */
    @Override
    public boolean requiresSecureConnection() {
        return requiresSecureConnection;
    }
}