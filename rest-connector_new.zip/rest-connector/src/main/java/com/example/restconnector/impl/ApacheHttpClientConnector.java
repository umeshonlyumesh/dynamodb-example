package com.example.restconnector.impl;

import com.example.restconnector.AbstractRestConnector;
import com.example.restconnector.RestConnectorException;
import com.example.restconnector.auth.AuthenticationStrategy;
import com.example.restconnector.auth.SslAuthStrategy;
import com.example.restconnector.model.HttpMethod;
import com.example.restconnector.model.RestRequest;
import com.example.restconnector.model.RestResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.classic.methods.*;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.ParseException;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.net.URIBuilder;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/**
 * Implementation of RestConnector using Apache HttpClient.
 */
@Slf4j
public class ApacheHttpClientConnector extends AbstractRestConnector {

    private final CloseableHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final int maxConnections;
    private final int maxConnectionsPerRoute;

    /**
     * Creates a new ApacheHttpClientConnector with default settings.
     */
    public ApacheHttpClientConnector() {
        this(null);
    }

    /**
     * Creates a new ApacheHttpClientConnector with the specified authentication strategy.
     *
     * @param authStrategy The authentication strategy to use
     */
    public ApacheHttpClientConnector(AuthenticationStrategy authStrategy) {
        this(authStrategy, 100, 20, null);
    }

    /**
     * Creates a new ApacheHttpClientConnector with the specified settings.
     *
     * @param authStrategy The authentication strategy to use
     * @param maxConnections The maximum number of connections
     * @param maxConnectionsPerRoute The maximum number of connections per route
     * @param executor The executor for asynchronous operations
     */
    public ApacheHttpClientConnector(AuthenticationStrategy authStrategy, int maxConnections, 
                                    int maxConnectionsPerRoute, Executor executor) {
        super(authStrategy, executor);
        this.maxConnections = maxConnections;
        this.maxConnectionsPerRoute = maxConnectionsPerRoute;
        this.objectMapper = new ObjectMapper();
        this.httpClient = createHttpClient();
    }

    /**
     * Executes a REST request and returns the response.
     *
     * @param request The request to execute
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    @Override
    public <T> RestResponse<T> execute(RestRequest request, Class<T> responseType) throws RestConnectorException {
        validateRequest(request);
        RestRequest authenticatedRequest = authenticateRequest(request);
        logRequest(authenticatedRequest);

        long startTime = System.currentTimeMillis();
        try {
            URI uri = buildUri(authenticatedRequest);
            HttpUriRequestBase httpRequest = createHttpRequest(authenticatedRequest, uri);
            addHeaders(httpRequest, authenticatedRequest.getHeaders());
            addBody(httpRequest, authenticatedRequest);

            try (CloseableHttpResponse response = httpClient.execute(httpRequest)) {

                RestResponse<T> restResponse = processResponse(response, responseType);
                long requestTime = System.currentTimeMillis() - startTime;
                restResponse.setRequestTimeMs(requestTime);
                logResponse(restResponse, requestTime);
                return restResponse;
            }
        } catch (Exception e) {
            long requestTime = System.currentTimeMillis() - startTime;
            log.error("Error executing request to {}: {} ({}ms)", 
                    authenticatedRequest.getUrl(), e.getMessage(), requestTime, e);
            throw new RestConnectorException("Error executing request: " + e.getMessage(), e);
        }
    }

    /**
     * Creates an HttpClient with the configured settings.
     */
    private CloseableHttpClient createHttpClient() {
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(maxConnections);
        connectionManager.setDefaultMaxPerRoute(maxConnectionsPerRoute);

        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectionRequestTimeout(30, TimeUnit.SECONDS)
                .setResponseTimeout(30, TimeUnit.SECONDS)
                .build();

        HttpClientBuilder builder = HttpClients.custom()
                .setConnectionManager(connectionManager)
                .setDefaultRequestConfig(requestConfig);

        // Configure SSL if an SSL authentication strategy is used
        if (authStrategy instanceof SslAuthStrategy) {
            SslAuthStrategy sslAuthStrategy = (SslAuthStrategy) authStrategy;
            SSLContext sslContext = sslAuthStrategy.getSslContext();

            SSLConnectionSocketFactory sslSocketFactory = sslAuthStrategy.isVerifyHostname()
                    ? new SSLConnectionSocketFactory(sslContext)
                    : new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            // In Apache HttpClient 5.x, the method is setSSLSocketFactory
            builder.setConnectionManager(
                PoolingHttpClientConnectionManagerBuilder.create()
                    .setSSLSocketFactory(sslSocketFactory)
                    .setMaxConnTotal(maxConnections)
                    .setMaxConnPerRoute(maxConnectionsPerRoute)
                    .build()
            );
        }

        return builder.build();
    }

    /**
     * Builds a URI from the request URL and query parameters.
     */
    private URI buildUri(RestRequest request) throws URISyntaxException {
        URIBuilder uriBuilder = new URIBuilder(request.getUrl());

        if (request.getQueryParams() != null && !request.getQueryParams().isEmpty()) {
            for (Map.Entry<String, String> entry : request.getQueryParams().entrySet()) {
                uriBuilder.addParameter(entry.getKey(), entry.getValue());
            }
        }

        return uriBuilder.build();
    }

    /**
     * Creates an HTTP request for the specified REST request and URI.
     */
    private HttpUriRequestBase createHttpRequest(RestRequest request, URI uri) {
        switch (request.getMethod()) {
            case GET:
                return new HttpGet(uri);
            case POST:
                return new HttpPost(uri);
            case PUT:
                return new HttpPut(uri);
            case DELETE:
                return new HttpDelete(uri);
            case PATCH:
                return new HttpPatch(uri);
            case HEAD:
                return new HttpHead(uri);
            case OPTIONS:
                return new HttpOptions(uri);
            default:
                throw new RestConnectorException("Unsupported HTTP method: " + request.getMethod());
        }
    }

    /**
     * Adds headers to the HTTP request.
     */
    private void addHeaders(HttpUriRequestBase httpRequest, Map<String, String> headers) {
        if (headers != null && !headers.isEmpty()) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                httpRequest.setHeader(entry.getKey(), entry.getValue());
            }
        }

        // Add default headers if not already present
        if (!httpRequest.containsHeader("Accept")) {
            httpRequest.setHeader("Accept", "application/json");
        }
    }

    /**
     * Adds a body to the HTTP request if applicable.
     */
    private void addBody(HttpUriRequestBase httpRequest, RestRequest request) throws IOException {
        if (!(httpRequest instanceof HttpGet || httpRequest instanceof HttpHead || 
              httpRequest instanceof HttpDelete || httpRequest instanceof HttpOptions) && 
            request.getBody() != null) {

            String json = objectMapper.writeValueAsString(request.getBody());
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);

            // In Apache HttpClient 5.x, HttpUriRequestBase has setEntity method for requests that can have a body
            // No need to check for HttpEntityEnclosingRequest interface
            if (httpRequest instanceof HttpPost || httpRequest instanceof HttpPut || 
                httpRequest instanceof HttpPatch) {

                // Cast to the appropriate type and set the entity
                if (httpRequest instanceof HttpPost) {
                    ((HttpPost) httpRequest).setEntity(entity);
                } else if (httpRequest instanceof HttpPut) {
                    ((HttpPut) httpRequest).setEntity(entity);
                } else if (httpRequest instanceof HttpPatch) {
                    ((HttpPatch) httpRequest).setEntity(entity);
                }

                // Add Content-Type header if not already present
                if (!httpRequest.containsHeader("Content-Type")) {
                    httpRequest.setHeader("Content-Type", "application/json");
                }
            }
        }
    }

    /**
     * Processes the HTTP response into a RestResponse.
     */
    private <T> RestResponse<T> processResponse(CloseableHttpResponse response, 
                                              Class<T> responseType) throws IOException {
        int statusCode = response.getCode();
        Map<String, String> headers = extractHeaders(response);
        String rawBody = null;
        T body = null;

        HttpEntity entity = response.getEntity();
        if (entity != null) {
            try {
                rawBody = EntityUtils.toString(entity);

                if (rawBody != null && !rawBody.isEmpty() && responseType != String.class) {
                    try {
                        body = objectMapper.readValue(rawBody, responseType);
                    } catch (Exception e) {
                        log.warn("Failed to deserialize response body to {}: {}", 
                                responseType.getName(), e.getMessage());
                        // If deserialization fails, return the raw body as is
                        if (responseType == String.class) {
                            body = (T) rawBody;
                        }
                    }
                } else if (responseType == String.class) {
                    body = (T) rawBody;
                }
            } catch (ParseException e) {
                log.warn("Failed to parse response body: {}", e.getMessage());
            }
        }

        return RestResponse.<T>builder()
                .statusCode(statusCode)
                .headers(headers)
                .body(body)
                .rawBody(rawBody)
                .build();
    }

    /**
     * Extracts headers from the HTTP response.
     */
    private Map<String, String> extractHeaders(CloseableHttpResponse response) {
        Map<String, String> headers = new HashMap<>();

        Header[] responseHeaders = response.getHeaders();
        if (responseHeaders != null) {
            for (Header header : responseHeaders) {
                headers.put(header.getName(), header.getValue());
            }
        }

        return headers;
    }
}
