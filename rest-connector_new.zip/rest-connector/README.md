# REST Connector

A flexible and extensible REST API client library for Java applications. This library provides a simple and consistent way to make REST API calls with support for various authentication methods including Basic Auth, OAuth 2.0, SSL/TLS, and mTLS.

## Features

- Support for all common HTTP methods (GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS)
- Multiple authentication strategies:
  - No authentication
  - Basic authentication
  - OAuth 2.0 (client credentials and password grant types)
  - SSL/TLS
  - Mutual TLS (mTLS)
- Synchronous and asynchronous request execution
- Type-safe response handling with automatic JSON serialization/deserialization
- Configurable connection and read timeouts
- Comprehensive error handling
- Built on Spring's RestTemplate for robust HTTP client capabilities

## Requirements

- Java 21 or higher
- Spring Boot 3.x

## Installation

Add the following dependency to your Maven project:

```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>rest-connector</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</dependency>
```

## Quick Start

### Making a Simple GET Request

```java
// Create a connector with no authentication
RestConnector connector = RestConnectorFactory.createNoAuthConnector();

// Make a GET request
RestResponse<String> response = connector.get(
        "https://api.example.com/data",
        null,
        null,
        String.class
);

// Process the response
if (response.isSuccessful()) {
    System.out.println("Response: " + response.getBody());
} else {
    System.err.println("Error: " + response.getStatusCode() + " - " + response.getRawBody());
}
```

### Making a POST Request with Basic Authentication

```java
// Create a connector with basic authentication
RestConnector connector = RestConnectorFactory.createBasicAuthConnector(
        "username",
        "password"
);

// Create request headers
Map<String, String> headers = new HashMap<>();
headers.put("X-Custom-Header", "custom-value");

// Create request body
Map<String, Object> body = new HashMap<>();
body.put("name", "John Doe");
body.put("email", "john.doe@example.com");

// Make a POST request
RestResponse<Map> response = connector.post(
        "https://api.example.com/users",
        body,
        headers,
        Map.class
);

// Process the response
if (response.isSuccessful()) {
    Map responseBody = response.getBody();
    System.out.println("User created with ID: " + responseBody.get("id"));
} else {
    System.err.println("Error creating user: " + response.getStatusCode());
}
```

## Authentication Methods

### No Authentication

```java
RestConnector connector = RestConnectorFactory.createNoAuthConnector();
```

### Basic Authentication

```java
RestConnector connector = RestConnectorFactory.createBasicAuthConnector(
        "username",
        "password"
);
```

### OAuth 2.0 Client Credentials

```java
RestConnector connector = RestConnectorFactory.createOAuth2ClientCredentialsConnector(
        "https://auth.example.com/oauth/token",
        "client-id",
        "client-secret"
);
```

### OAuth 2.0 Password Grant

```java
RestConnector connector = RestConnectorFactory.createOAuth2PasswordConnector(
        "https://auth.example.com/oauth/token",
        "client-id",
        "client-secret",
        "username",
        "password"
);
```

### Mutual TLS (mTLS)

```java
RestConnector connector = RestConnectorFactory.createMtlsConnector(
        "path/to/keystore.p12",
        "keystore-password",
        "path/to/truststore.jks",
        "truststore-password"
);
```

## Advanced Usage

### Custom Request Configuration

```java
// Create a custom request with all parameters
Map<String, String> queryParams = new HashMap<>();
queryParams.put("q", "search term");
queryParams.put("limit", "10");

Map<String, String> headers = new HashMap<>();
headers.put("Accept-Language", "en-US");

RestRequest request = RestRequest.builder()
        .url("https://api.example.com/search")
        .method(HttpMethod.GET)
        .queryParams(queryParams)
        .headers(headers)
        .connectionTimeout(5000)
        .readTimeout(5000)
        .followRedirects(true)
        .build();

// Execute the request
RestResponse<Map> response = connector.execute(request, Map.class);
```

### Asynchronous Requests

```java
// Create a request
RestRequest request = RestRequest.builder()
        .url("https://api.example.com/data")
        .method(HttpMethod.GET)
        .build();

// Execute the request asynchronously
connector.executeAsync(request, String.class)
        .thenAccept(response -> {
            if (response.isSuccessful()) {
                System.out.println("Async response: " + response.getBody());
            } else {
                System.err.println("Async error: " + response.getStatusCode());
            }
        })
        .exceptionally(ex -> {
            System.err.println("Async exception: " + ex.getMessage());
            return null;
        });
```

## Error Handling

The library provides comprehensive error handling through the `RestConnectorException` class and the `RestResponse` object:

```java
try {
    RestResponse<String> response = connector.get("https://api.example.com/data", null, null, String.class);
    
    if (response.isSuccessful()) {
        // Process successful response
    } else if (response.isClientError()) {
        // Handle client errors (4xx)
        System.err.println("Client error: " + response.getStatusCode());
    } else if (response.isServerError()) {
        // Handle server errors (5xx)
        System.err.println("Server error: " + response.getStatusCode());
    }
} catch (RestConnectorException e) {
    // Handle connection or other errors
    System.err.println("Error: " + e.getMessage());
    if (e.getStatusCode() > 0) {
        System.err.println("Status code: " + e.getStatusCode());
    }
}
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.