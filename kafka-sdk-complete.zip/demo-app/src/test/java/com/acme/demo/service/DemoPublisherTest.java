package com.acme.demo.service;

import com.acme.kafkasdk.producer.KafkaProducerClient;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class DemoPublisherTest {
    @Test
    void publish_delegates() {
        KafkaProducerClient client = mock(KafkaProducerClient.class);
        DemoPublisher pub = new DemoPublisher(client);
        pub.publish("hi");
        verify(client).sendAsync(eq("demo-topic"), isNull(), eq("hi"));
    }
}
