package com.acme.demo.service;

import com.acme.kafkasdk.producer.KafkaProducerClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DemoPublisher {
    private final KafkaProducerClient producer;
    public void publish(Object payload) {
        producer.sendAsync("demo-topic", null, payload);
    }
}
