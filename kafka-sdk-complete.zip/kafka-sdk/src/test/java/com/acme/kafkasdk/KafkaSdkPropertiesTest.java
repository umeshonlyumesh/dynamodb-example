package com.acme.kafkasdk;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class KafkaSdkPropertiesTest {
    @Test
    void defaults_and_setters() {
        KafkaSdkProperties p = new KafkaSdkProperties();
        assertEquals("app", p.getClientId());
        p.setBootstrapServers("localhost:9092");
        assertEquals("localhost:9092", p.getBootstrapServers());
        p.getConsumer().setGroupId("g1");
        assertEquals("g1", p.getConsumer().getGroupId());
        p.getProducer().setAcks("1");
        assertEquals("1", p.getProducer().getAcks());
        p.getProducer().setDefaultDlqTopic("dlq");
        assertEquals("dlq", p.getProducer().getDefaultDlqTopic());
    }
}
