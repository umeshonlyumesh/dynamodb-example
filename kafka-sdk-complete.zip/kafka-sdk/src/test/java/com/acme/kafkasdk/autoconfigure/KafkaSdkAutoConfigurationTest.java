package com.acme.kafkasdk.autoconfigure;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import com.acme.kafkasdk.producer.KafkaProducerClient;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import static org.assertj.core.api.Assertions.assertThat;

public class KafkaSdkAutoConfigurationTest {

    private final ApplicationContextRunner ctx = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(KafkaSdkAutoConfiguration.class))
            .withPropertyValues(
                "kafka.sdk.bootstrap-servers=localhost:9092",
                "kafka.sdk.consumer.group-id=test-group");

    @Test
    void autoConfig_createsBeans() {
        ctx.run(context -> {
            assertThat(context).hasSingleBean(KafkaProducerClient.class);
            assertThat(context).hasSingleBean(org.springframework.kafka.core.KafkaTemplate.class);
            assertThat(context).hasSingleBean(org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory.class);
        });
    }
}
