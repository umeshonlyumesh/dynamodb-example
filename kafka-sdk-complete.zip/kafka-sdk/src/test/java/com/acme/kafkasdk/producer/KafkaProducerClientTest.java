package com.acme.kafkasdk.producer;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.SettableListenableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class KafkaProducerClientTest {

    @Test
    void sendSync_success() throws Exception {
        KafkaTemplate<Object, Object> template = mock(KafkaTemplate.class);
        KafkaSdkProperties props = new KafkaSdkProperties();
        KafkaProducerClient client = new KafkaProducerClient(template, props);

        SettableListenableFuture<SendResult<Object, Object>> fut = new SettableListenableFuture<>();
        RecordMetadata md = new RecordMetadata(new TopicPartition("t", 0), 0, 42, 1L, 0L, 0, 0);
        SendResult<Object, Object> sr = new SendResult<>(null, md);
        fut.set(sr);
        when(template.send("t", "k", "v")).thenReturn(fut);

        RecordMetadata out = client.sendSync("t", "k", "v");
        assertEquals(42, out.offset());
        verify(template).send("t", "k", "v");
    }

    @Test
    void sendAsync_success() {
        KafkaTemplate<Object, Object> template = mock(KafkaTemplate.class);
        KafkaSdkProperties props = new KafkaSdkProperties();
        KafkaProducerClient client = new KafkaProducerClient(template, props);

        SettableListenableFuture<SendResult<Object, Object>> fut = new SettableListenableFuture<>();
        RecordMetadata md = new RecordMetadata(new TopicPartition("t", 0), 0, 1, 1L, 0L, 0, 0);
        fut.set(new SendResult<>(null, md));
        when(template.send("t", "k", "v")).thenReturn(fut);

        var res = client.sendAsync("t", "k", "v");
        assertTrue(res.isDone());
        verify(template).send("t", "k", "v");
    }

    @Test
    void sendSync_failure_publishes_to_default_dlq() {
        KafkaTemplate<Object, Object> template = mock(KafkaTemplate.class);
        KafkaSdkProperties props = new KafkaSdkProperties();
        props.getProducer().setDefaultDlqTopic("dlq-topic");
        KafkaProducerClient client = new KafkaProducerClient(template, props);

        SettableListenableFuture<SendResult<Object, Object>> fut = new SettableListenableFuture<>();
        fut.setException(new RuntimeException("boom"));
        when(template.send("t", "k", "v")).thenReturn(fut);
        when(template.send(eq("dlq-topic"), eq("k"), eq("v"))).thenReturn(new SettableListenableFuture<>());

        assertThrows(Exception.class, () -> client.sendSync("t", "k", "v"));
        verify(template).send("dlq-topic", "k", "v");
    }
}
