package com.acme.kafkasdk.autoconfigure;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import com.acme.kafkasdk.producer.KafkaProducerClient;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

@AutoConfiguration
@EnableConfigurationProperties(KafkaSdkProperties.class)
public class KafkaSdkAutoConfiguration {

    @Bean
    public ProducerFactory<Object, Object> producerFactory(KafkaSdkProperties props) {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        cfg.put(ProducerConfig.ACKS_CONFIG, props.getProducer().getAcks());
        cfg.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, props.getProducer().isIdempotence());
        cfg.put(ProducerConfig.LINGER_MS_CONFIG, props.getProducer().getLingerMs());
        cfg.put(ProducerConfig.RETRIES_CONFIG, props.getProducer().getRetries());
        cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        cfg.put("security.protocol", props.getSecurity().getProtocol());
        cfg.put("sasl.mechanism", props.getSecurity().getMechanism());
        if (props.getSecurity().getUsername() != null && props.getSecurity().getPassword() != null) {
            cfg.put("sasl.jaas.config", String.format(
                "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"%s\" password=\"%s\";",
                props.getSecurity().getUsername(), props.getSecurity().getPassword()));
        }
        cfg.put("ssl.endpoint.identification.algorithm", props.getSsl().getEndpointIdentificationAlgorithm());
        return new DefaultKafkaProducerFactory<>(cfg);
    }

    @Bean
    public KafkaTemplate<Object, Object> kafkaTemplate(ProducerFactory<Object, Object> pf) {
        return new KafkaTemplate<>(pf);
    }

    @Bean
    public KafkaProducerClient kafkaProducerClient(KafkaTemplate<Object, Object> template, KafkaSdkProperties props) {
        return new KafkaProducerClient(template, props);
    }

    @Bean
    public ConsumerFactory<Object, Object> consumerFactory(KafkaSdkProperties props) {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        cfg.put(ConsumerConfig.GROUP_ID_CONFIG, props.getConsumer().getGroupId());
        cfg.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, props.getConsumer().getAutoOffsetReset());
        cfg.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        cfg.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        cfg.put(JsonDeserializer.TRUSTED_PACKAGES, "*");

        cfg.put("security.protocol", props.getSecurity().getProtocol());
        cfg.put("sasl.mechanism", props.getSecurity().getMechanism());
        if (props.getSecurity().getUsername() != null && props.getSecurity().getPassword() != null) {
            cfg.put("sasl.jaas.config", String.format(
                "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"%s\" password=\"%s\";",
                props.getSecurity().getUsername(), props.getSecurity().getPassword()));
        }
        cfg.put("ssl.endpoint.identification.algorithm", props.getSsl().getEndpointIdentificationAlgorithm());
        return new DefaultKafkaConsumerFactory<>(cfg);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<Object, Object> kafkaListenerContainerFactory(
            ConsumerFactory<Object, Object> cf, KafkaSdkProperties props) {
        ConcurrentKafkaListenerContainerFactory<Object, Object> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(cf);
        factory.setConcurrency(props.getConsumer().getConcurrency());
        return factory;
    }
}
