package com.acme.kafkasdk.producer;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;

@Slf4j
@RequiredArgsConstructor
public class KafkaProducerClient {
    private final KafkaTemplate<Object, Object> template;
    private final KafkaSdkProperties props;

    public ListenableFuture<SendResult<Object, Object>> sendAsync(String topic, Object key, Object value) {
        return sendAsync(topic, key, value, null);
    }

    public ListenableFuture<SendResult<Object, Object>> sendAsync(String topic, Object key, Object value, String dlqTopic) {
        log.info("Sending async to topic={} key={}", topic, key);
        ListenableFuture<SendResult<Object, Object>> future = template.send(topic, key, value);
        future.addCallback(
            result -> log.info("Async send ok topic={} partition={} offset={}",
                result.getRecordMetadata().topic(),
                result.getRecordMetadata().partition(),
                result.getRecordMetadata().offset()),
            ex -> {
                log.error("Async send failed topic={} key={} error={}", topic, key, ex.toString());
                publishToDlq(dlqTopic, key, value);
            }
        );
        return future;
    }

    public RecordMetadata sendSync(String topic, Object key, Object value) throws Exception {
        return sendSync(topic, key, value, null);
    }

    public RecordMetadata sendSync(String topic, Object key, Object value, String dlqTopic) throws Exception {
        try {
            SendResult<Object, Object> res = template.send(topic, key, value).get();
            RecordMetadata md = res.getRecordMetadata();
            log.info("Sync send ok topic={} partition={} offset={}", md.topic(), md.partition(), md.offset());
            return md;
        } catch (Exception ex) {
            log.error("Sync send failed topic={} key={} error={}", topic, key, ex.toString());
            publishToDlq(dlqTopic, key, value);
            throw ex;
        }
    }

    private void publishToDlq(String dlqTopic, Object key, Object value) {
        String target = dlqTopic != null ? dlqTopic : props.getProducer().getDefaultDlqTopic();
        if (target == null) {
            log.warn("DLQ topic not configured; message dropped. key={}, value={}", key, value);
            return;
        }
        try {
            template.send(target, key, value);
            log.info("Published to DLQ topic={} key={}", target, key);
        } catch (Exception e) {
            log.error("Failed to publish to DLQ topic={} key={} error={}", target, key, e.toString());
        }
    }
}
