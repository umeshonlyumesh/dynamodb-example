package com.acme.kafkasdk.autoconfigure;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import com.acme.kafkasdk.producer.KafkaProducerClient;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

@AutoConfiguration
@EnableConfigurationProperties(KafkaSdkProperties.class)
public class KafkaSdkAutoConfiguration {

    @Bean
    public ProducerFactory<Object, Object> producerFactory(KafkaSdkProperties props) {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        cfg.put(ProducerConfig.ACKS_CONFIG, props.getProducer().getAcks());
        cfg.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, props.getProducer().isIdempotence());
        cfg.put(ProducerConfig.LINGER_MS_CONFIG, props.getProducer().getLingerMs());
        cfg.put(ProducerConfig.RETRIES_CONFIG, props.getProducer().getRetries());
        cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        cfg.put("security.protocol", props.getSecurity().getProtocol());
        cfg.put("sasl.mechanism", props.getSecurity().getMechanism());
        if (props.getSecurity().getUsername() != null && props.getSecurity().getPassword() != null) {
            cfg.put("sasl.jaas.config", String.format(
                "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"%s\" password=\"%s\";",
                props.getSecurity().getUsername(), props.getSecurity().getPassword()));
        }
        cfg.put("ssl.endpoint.identification.algorithm", props.getSsl().getEndpointIdentificationAlgorithm());

        return new DefaultKafkaProducerFactory<>(cfg);
    }

    @Bean
    public KafkaTemplate<Object, Object> kafkaTemplate(ProducerFactory<Object, Object> pf) {
        return new KafkaTemplate<>(pf);
    }

    @Bean
    public KafkaProducerClient kafkaProducerClient(KafkaTemplate<Object, Object> template) {
        return new KafkaProducerClient(template);
    }
}
