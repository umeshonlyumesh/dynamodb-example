package com.acme.kafkasdk.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "kafka.sdk")
public class KafkaSdkProperties {
    private String bootstrapServers;
    private String clientId = "app";
    private Security security = new Security();
    private Ssl ssl = new Ssl();
    private Consumer consumer = new Consumer();
    private Producer producer = new Producer();

    @Data
    public static class Security {
        private String protocol = "SASL_SSL";
        private String mechanism = "PLAIN";
        private String username;
        private String password;
    }

    @Data
    public static class Ssl {
        private String endpointIdentificationAlgorithm = "https";
        private String truststoreLocation;
        private String truststorePassword;
    }

    @Data
    public static class Consumer {
        private String groupId = "default-group";
        private int concurrency = 3;
        private boolean enableDlq = true;
        private String autoOffsetReset = "earliest";
    }

    @Data
    public static class Producer {
        private int retries = 3;
        private int lingerMs = 5;
        private String acks = "all";
        private boolean idempotence = true;
    }
}
