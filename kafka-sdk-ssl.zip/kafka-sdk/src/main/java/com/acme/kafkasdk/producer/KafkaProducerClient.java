package com.acme.kafkasdk.producer;

import com.acme.kafkasdk.config.KafkaSdkProperties;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;

@RequiredArgsConstructor
public class KafkaProducerClient {
    private final KafkaTemplate<Object, Object> template;
    private final KafkaSdkProperties props;

    public ListenableFuture<SendResult<Object, Object>> sendAsync(String topic, Object key, Object value) {
        return template.send(topic, key, value);
    }

    public RecordMetadata sendSync(String topic, Object key, Object value) throws Exception {
        return template.send(topic, key, value).get().getRecordMetadata();
    }
}
