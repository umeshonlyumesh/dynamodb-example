package com.example.restconnector.model;

/**
 * Enum representing HTTP methods supported by the REST connector.
 */
public enum HttpMethod {
    GET,
    POST,
    PUT,
    DELETE,
    PATCH,
    HEAD,
    OPTIONS
}