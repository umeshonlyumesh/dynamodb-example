package com.example.restconnector.model;

import lombok.Builder;
import lombok.Data;

import java.util.Map;

/**
 * Represents a REST API response with all relevant information.
 */
@Data
@Builder
public class RestResponse<T> {
    /**
     * HTTP status code of the response.
     */
    private int statusCode;
    
    /**
     * Response headers.
     */
    private Map<String, String> headers;
    
    /**
     * Response body, deserialized to the specified type.
     */
    private T body;
    
    /**
     * Raw response body as string.
     */
    private String rawBody;
    
    /**
     * Time taken for the request in milliseconds.
     */
    private long requestTimeMs;
    
    /**
     * Checks if the response status code indicates success (2xx).
     * 
     * @return true if the status code is between 200 and 299, false otherwise
     */
    public boolean isSuccessful() {
        return statusCode >= 200 && statusCode < 300;
    }
    
    /**
     * Checks if the response status code indicates a client error (4xx).
     * 
     * @return true if the status code is between 400 and 499, false otherwise
     */
    public boolean isClientError() {
        return statusCode >= 400 && statusCode < 500;
    }
    
    /**
     * Checks if the response status code indicates a server error (5xx).
     * 
     * @return true if the status code is between 500 and 599, false otherwise
     */
    public boolean isServerError() {
        return statusCode >= 500 && statusCode < 600;
    }
    
    /**
     * Gets a header value by name.
     * 
     * @param name Header name
     * @return Header value or null if not found
     */
    public String getHeader(String name) {
        return headers != null ? headers.get(name) : null;
    }
}