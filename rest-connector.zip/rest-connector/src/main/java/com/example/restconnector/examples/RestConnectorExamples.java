package com.example.restconnector.examples;

import com.example.restconnector.RestConnector;
import com.example.restconnector.RestConnectorFactory;
import com.example.restconnector.model.RestRequest;
import com.example.restconnector.model.RestResponse;
import com.example.restconnector.ssl.SslContextFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Examples of how to use the REST connector with different authentication methods.
 * This class is for demonstration purposes only and is not meant to be executed directly.
 */
public class RestConnectorExamples {

    /**
     * Example of making a simple GET request with no authentication.
     */
    public void noAuthExample() {
        // Create a connector with no authentication
        RestConnector connector = RestConnectorFactory.createNoAuthConnector();

        // Make a GET request
        RestResponse<String> response = connector.get(
                "https://api.example.com/data",
                null,
                null,
                String.class
        );

        // Process the response
        if (response.isSuccessful()) {
            System.out.println("Response: " + response.getBody());
        } else {
            System.err.println("Error: " + response.getStatusCode() + " - " + response.getRawBody());
        }
    }

    /**
     * Example of making a POST request with basic authentication.
     */
    public void basicAuthExample() {
        // Create a connector with basic authentication
        RestConnector connector = RestConnectorFactory.createBasicAuthConnector(
                "username",
                "password"
        );

        // Create request headers
        Map<String, String> headers = new HashMap<>();
        headers.put("X-Custom-Header", "custom-value");

        // Create request body
        Map<String, Object> body = new HashMap<>();
        body.put("name", "John Doe");
        body.put("email", "john.doe@example.com");

        // Make a POST request
        RestResponse<Map> response = connector.post(
                "https://api.example.com/users",
                body,
                headers,
                Map.class
        );

        // Process the response
        if (response.isSuccessful()) {
            Map responseBody = response.getBody();
            System.out.println("User created with ID: " + responseBody.get("id"));
        } else {
            System.err.println("Error creating user: " + response.getStatusCode());
        }
    }

    /**
     * Example of making a request with OAuth 2.0 client credentials authentication.
     */
    public void oauth2ClientCredentialsExample() {
        // Create a connector with OAuth 2.0 client credentials authentication
        RestConnector connector = RestConnectorFactory.createOAuth2ClientCredentialsConnector(
                "https://auth.example.com/oauth/token",
                "client-id",
                "client-secret"
        );

        // Make a GET request
        RestResponse<Map> response = connector.get(
                "https://api.example.com/protected-resource",
                null,
                null,
                Map.class
        );

        // Process the response
        if (response.isSuccessful()) {
            System.out.println("Protected resource: " + response.getBody());
        } else {
            System.err.println("Error accessing protected resource: " + response.getStatusCode());
        }
    }

    /**
     * Example of making a request with mTLS (mutual TLS) authentication.
     */
    public void mtlsExample() {
        // Create a connector with mTLS authentication
        RestConnector connector = RestConnectorFactory.createMtlsConnector(
                "path/to/keystore.p12",
                "keystore-password",
                "path/to/truststore.jks",
                "truststore-password"
        );

        // Make a GET request
        RestResponse<String> response = connector.get(
                "https://api.example.com/secure-resource",
                null,
                null,
                String.class
        );

        // Process the response
        if (response.isSuccessful()) {
            System.out.println("Secure resource: " + response.getBody());
        } else {
            System.err.println("Error accessing secure resource: " + response.getStatusCode());
        }
    }

    /**
     * Example of making a request with a custom request object.
     */
    public void customRequestExample() {
        // Create a connector with no authentication
        RestConnector connector = RestConnectorFactory.createNoAuthConnector();

        // Create a custom request with all parameters
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("q", "search term");
        queryParams.put("limit", "10");

        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", "en-US");

        RestRequest request = RestRequest.builder()
                .url("https://api.example.com/search")
                .method(com.example.restconnector.model.HttpMethod.GET)
                .queryParams(queryParams)
                .headers(headers)
                .connectionTimeout(5000)
                .readTimeout(5000)
                .followRedirects(true)
                .build();

        // Alternatively, you can add headers and query params after building
        // RestRequest request = RestRequest.builder()
        //         .url("https://api.example.com/search")
        //         .method(com.example.restconnector.model.HttpMethod.GET)
        //         .build();
        // request.addQueryParam("q", "search term");
        // request.addQueryParam("limit", "10");
        // request.addHeader("Accept-Language", "en-US");

        // Execute the request
        RestResponse<Map> response = connector.execute(request, Map.class);

        // Process the response
        if (response.isSuccessful()) {
            System.out.println("Search results: " + response.getBody());
            System.out.println("Request time: " + response.getRequestTimeMs() + "ms");
        } else {
            System.err.println("Error performing search: " + response.getStatusCode());
        }
    }

    /**
     * Example of making an asynchronous request.
     */
    public void asyncRequestExample() {
        // Create a connector with no authentication
        RestConnector connector = RestConnectorFactory.createNoAuthConnector();

        // Create a request
        RestRequest request = RestRequest.builder()
                .url("https://api.example.com/data")
                .method(com.example.restconnector.model.HttpMethod.GET)
                .build();

        // Execute the request asynchronously
        connector.executeAsync(request, String.class)
                .thenAccept(response -> {
                    if (response.isSuccessful()) {
                        System.out.println("Async response: " + response.getBody());
                    } else {
                        System.err.println("Async error: " + response.getStatusCode());
                    }
                })
                .exceptionally(ex -> {
                    System.err.println("Async exception: " + ex.getMessage());
                    return null;
                });

        // Continue with other operations while the request is being processed
        System.out.println("Async request sent, continuing with other operations...");
    }
}
