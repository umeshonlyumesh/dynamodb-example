package com.example.restconnector.impl;

import com.example.restconnector.AbstractRestConnector;
import com.example.restconnector.RestConnectorException;
import com.example.restconnector.auth.AuthenticationStrategy;
import com.example.restconnector.auth.SslAuthStrategy;
import com.example.restconnector.model.HttpMethod;
import com.example.restconnector.model.RestRequest;
import com.example.restconnector.model.RestResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

import javax.net.ssl.SSLContext;
import java.net.URI;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

/**
 * Implementation of RestConnector using Spring's RestClient.
 * This replaces the older RestTemplate-based implementation with the newer RestClient API.
 */
@Slf4j
public class RestClientConnector extends AbstractRestConnector {

    private final RestClient restClient;

    /**
     * Creates a new RestClientConnector with default settings.
     */
    public RestClientConnector() {
        this(null);
    }

    /**
     * Creates a new RestClientConnector with the specified authentication strategy.
     *
     * @param authStrategy The authentication strategy to use
     */
    public RestClientConnector(AuthenticationStrategy authStrategy) {
        this(authStrategy, null);
    }

    /**
     * Creates a new RestClientConnector with the specified authentication strategy and executor.
     *
     * @param authStrategy The authentication strategy to use
     * @param executor The executor for asynchronous operations
     */
    public RestClientConnector(AuthenticationStrategy authStrategy, Executor executor) {
        super(authStrategy, executor);
        this.restClient = createRestClient();
    }

    /**
     * Executes a REST request and returns the response.
     *
     * @param request The request to execute
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    @Override
    public <T> RestResponse<T> execute(RestRequest request, Class<T> responseType) throws RestConnectorException {
        validateRequest(request);
        RestRequest authenticatedRequest = authenticateRequest(request);
        logRequest(authenticatedRequest);

        long startTime = System.currentTimeMillis();
        try {
            URI uri = buildUri(authenticatedRequest);
            HttpHeaders headers = createHeaders(authenticatedRequest);

            RestClient.RequestBodySpec requestSpec = restClient.method(convertHttpMethod(authenticatedRequest.getMethod()))
                    .uri(uri)
                    .headers(httpHeaders -> httpHeaders.addAll(headers));

            if (authenticatedRequest.getBody() != null) {
                requestSpec = requestSpec.body(authenticatedRequest.getBody());
            }

            RestClient.ResponseSpec responseSpec = requestSpec.retrieve();

            // Handle both success and error responses
            org.springframework.http.ResponseEntity<T> responseEntity = responseSpec
                    .toEntity(responseType);

            RestResponse<T> restResponse = createSuccessResponse(responseEntity, startTime);
            logResponse(restResponse, restResponse.getRequestTimeMs());
            return restResponse;

        } catch (org.springframework.web.client.RestClientException e) {
            long requestTime = System.currentTimeMillis() - startTime;
            log.error("Error executing request to {}: {} ({}ms)", 
                    authenticatedRequest.getUrl(), e.getMessage(), requestTime, e);
            throw new RestConnectorException("Error executing request: " + e.getMessage(), e);
        } catch (Exception e) {
            long requestTime = System.currentTimeMillis() - startTime;
            log.error("Error executing request to {}: {} ({}ms)", 
                    authenticatedRequest.getUrl(), e.getMessage(), requestTime, e);
            throw new RestConnectorException("Error executing request: " + e.getMessage(), e);
        }
    }

    /**
     * Creates a RestClient with the configured settings.
     */
    private RestClient createRestClient() {
        // Create a RestClient with default settings
        // In Spring Boot 3.5.5, we can use the builder pattern without explicit timeout configuration
        // as it will use the default timeouts from the underlying HTTP client

        RestClient.Builder builder = RestClient.builder();

        // If SSL configuration is needed, it would go here
        // For example, if using SslAuthStrategy:
        // if (authStrategy instanceof SslAuthStrategy) {
        //     SslAuthStrategy sslAuthStrategy = (SslAuthStrategy) authStrategy;
        //     SSLContext sslContext = sslAuthStrategy.getSslContext();
        //     // Configure SSL context in the client
        // }

        return builder.build();
    }

    /**
     * Builds a URI from the request URL and query parameters.
     */
    private URI buildUri(RestRequest request) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(request.getUrl());

        if (request.getQueryParams() != null && !request.getQueryParams().isEmpty()) {
            for (Map.Entry<String, String> entry : request.getQueryParams().entrySet()) {
                builder.queryParam(entry.getKey(), entry.getValue());
            }
        }

        return builder.build().toUri();
    }

    /**
     * Creates HTTP headers from the request headers.
     */
    private HttpHeaders createHeaders(RestRequest request) {
        HttpHeaders headers = new HttpHeaders();

        if (request.getHeaders() != null && !request.getHeaders().isEmpty()) {
            for (Map.Entry<String, String> entry : request.getHeaders().entrySet()) {
                headers.add(entry.getKey(), entry.getValue());
            }
        }

        // Add default headers if not already present
        if (!headers.containsKey(HttpHeaders.ACCEPT)) {
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        }

        if (request.getBody() != null && !headers.containsKey(HttpHeaders.CONTENT_TYPE)) {
            headers.setContentType(MediaType.APPLICATION_JSON);
        }

        return headers;
    }

    /**
     * Converts our HttpMethod enum to Spring's HttpMethod.
     */
    private org.springframework.http.HttpMethod convertHttpMethod(HttpMethod method) {
        switch (method) {
            case GET:
                return org.springframework.http.HttpMethod.GET;
            case POST:
                return org.springframework.http.HttpMethod.POST;
            case PUT:
                return org.springframework.http.HttpMethod.PUT;
            case DELETE:
                return org.springframework.http.HttpMethod.DELETE;
            case PATCH:
                return org.springframework.http.HttpMethod.PATCH;
            case HEAD:
                return org.springframework.http.HttpMethod.HEAD;
            case OPTIONS:
                return org.springframework.http.HttpMethod.OPTIONS;
            default:
                throw new RestConnectorException("Unsupported HTTP method: " + method);
        }
    }

    /**
     * Creates a success response from a ResponseEntity.
     */
    private <T> RestResponse<T> createSuccessResponse(org.springframework.http.ResponseEntity<T> responseEntity, long startTime) {
        long requestTime = System.currentTimeMillis() - startTime;

        Map<String, String> headers = new HashMap<>();
        responseEntity.getHeaders().forEach((name, values) -> {
            if (!values.isEmpty()) {
                headers.put(name, String.join(", ", values));
            }
        });

        return RestResponse.<T>builder()
                .statusCode(responseEntity.getStatusCode().value())
                .headers(headers)
                .body(responseEntity.getBody())
                .requestTimeMs(requestTime)
                .build();
    }
}
