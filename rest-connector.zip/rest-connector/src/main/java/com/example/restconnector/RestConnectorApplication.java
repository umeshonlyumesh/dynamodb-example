package com.example.restconnector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestConnectorApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestConnectorApplication.class, args);
    }

}
