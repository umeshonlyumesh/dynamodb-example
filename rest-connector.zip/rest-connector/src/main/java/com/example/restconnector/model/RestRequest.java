package com.example.restconnector.model;

import lombok.Builder;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a REST API request with all necessary parameters.
 */
@Data
@Builder
public class RestRequest {
    /**
     * The URL to send the request to.
     */
    private String url;
    
    /**
     * The HTTP method to use for the request.
     */
    private HttpMethod method;
    
    /**
     * Headers to include in the request.
     */
    @Builder.Default
    private Map<String, String> headers = new HashMap<>();
    
    /**
     * Query parameters to include in the request URL.
     */
    @Builder.Default
    private Map<String, String> queryParams = new HashMap<>();
    
    /**
     * The request body as an Object. Will be serialized to JSON by default.
     */
    private Object body;
    
    /**
     * Connection timeout in milliseconds.
     */
    @Builder.Default
    private int connectionTimeout = 30000;
    
    /**
     * Read timeout in milliseconds.
     */
    @Builder.Default
    private int readTimeout = 30000;
    
    /**
     * Whether to follow redirects.
     */
    @Builder.Default
    private boolean followRedirects = true;
    
    /**
     * Adds a header to the request.
     * 
     * @param name Header name
     * @param value Header value
     * @return This request object for chaining
     */
    public RestRequest addHeader(String name, String value) {
        headers.put(name, value);
        return this;
    }
    
    /**
     * Adds a query parameter to the request.
     * 
     * @param name Parameter name
     * @param value Parameter value
     * @return This request object for chaining
     */
    public RestRequest addQueryParam(String name, String value) {
        queryParams.put(name, value);
        return this;
    }
}