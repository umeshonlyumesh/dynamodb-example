package com.example.restconnector;

import com.example.restconnector.auth.AuthenticationStrategy;
import com.example.restconnector.auth.NoAuthStrategy;
import com.example.restconnector.model.RestRequest;
import com.example.restconnector.model.RestResponse;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Abstract base implementation of the RestConnector interface.
 * Provides common functionality and handles authentication strategies.
 */
@Slf4j
public abstract class AbstractRestConnector implements RestConnector {

    /**
     * The authentication strategy to use for requests.
     */
    protected final AuthenticationStrategy authStrategy;
    
    /**
     * Executor for asynchronous operations.
     */
    protected final Executor executor;
    
    /**
     * Creates a new AbstractRestConnector with the specified authentication strategy and a default executor.
     *
     * @param authStrategy The authentication strategy to use
     */
    protected AbstractRestConnector(AuthenticationStrategy authStrategy) {
        this(authStrategy, Executors.newCachedThreadPool());
    }
    
    /**
     * Creates a new AbstractRestConnector with the specified authentication strategy and executor.
     *
     * @param authStrategy The authentication strategy to use
     * @param executor The executor for asynchronous operations
     */
    protected AbstractRestConnector(AuthenticationStrategy authStrategy, Executor executor) {
        this.authStrategy = authStrategy != null ? authStrategy : new NoAuthStrategy();
        this.executor = executor;
    }
    
    /**
     * Executes a REST request asynchronously and returns a CompletableFuture for the response.
     *
     * @param request The request to execute
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return A CompletableFuture that will complete with the response
     */
    @Override
    public <T> CompletableFuture<RestResponse<T>> executeAsync(RestRequest request, Class<T> responseType) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return execute(request, responseType);
            } catch (Exception e) {
                log.error("Error executing async request to {}: {}", request.getUrl(), e.getMessage(), e);
                throw new RestConnectorException("Error executing async request", e);
            }
        }, executor);
    }
    
    /**
     * Authenticates a request using the configured authentication strategy.
     *
     * @param request The request to authenticate
     * @return The authenticated request
     */
    protected RestRequest authenticateRequest(RestRequest request) {
        try {
            return authStrategy.authenticate(request);
        } catch (Exception e) {
            log.error("Error authenticating request: {}", e.getMessage(), e);
            throw new RestConnectorException("Error authenticating request", e);
        }
    }
    
    /**
     * Validates that a request can be executed.
     * Checks for required fields and ensures that secure connections are used when required.
     *
     * @param request The request to validate
     * @throws RestConnectorException if the request is invalid
     */
    protected void validateRequest(RestRequest request) {
        if (request.getUrl() == null || request.getUrl().isEmpty()) {
            throw new RestConnectorException("Request URL cannot be null or empty");
        }
        
        if (request.getMethod() == null) {
            throw new RestConnectorException("Request method cannot be null");
        }
        
        if (authStrategy.requiresSecureConnection() && !request.getUrl().toLowerCase().startsWith("https")) {
            throw new RestConnectorException(
                    "Authentication strategy " + authStrategy.getName() + " requires a secure connection (HTTPS)");
        }
    }
    
    /**
     * Logs information about a request before execution.
     *
     * @param request The request to log
     */
    protected void logRequest(RestRequest request) {
        log.debug("Executing {} request to {} with auth strategy: {}", 
                request.getMethod(), request.getUrl(), authStrategy.getName());
    }
    
    /**
     * Logs information about a response after execution.
     *
     * @param response The response to log
     * @param requestTimeMs The time taken for the request in milliseconds
     */
    protected void logResponse(RestResponse<?> response, long requestTimeMs) {
        log.debug("Received response with status code {} in {} ms", 
                response.getStatusCode(), requestTimeMs);
    }
}