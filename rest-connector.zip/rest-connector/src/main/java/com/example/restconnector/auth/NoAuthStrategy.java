package com.example.restconnector.auth;

import com.example.restconnector.model.RestRequest;

/**
 * Authentication strategy for requests that don't require authentication.
 * This is a pass-through implementation that doesn't modify the request.
 */
public class NoAuthStrategy implements AuthenticationStrategy {

    /**
     * Returns the request without any modifications.
     *
     * @param request The request to authenticate
     * @return The same request without modifications
     */
    @Override
    public RestRequest authenticate(RestRequest request) {
        return request;
    }

    /**
     * Gets the name of this authentication strategy.
     *
     * @return "NoAuth"
     */
    @Override
    public String getName() {
        return "NoAuth";
    }

    /**
     * Checks if this authentication strategy requires SSL/TLS.
     *
     * @return false, as no authentication doesn't require a secure connection
     */
    @Override
    public boolean requiresSecureConnection() {
        return false;
    }
}