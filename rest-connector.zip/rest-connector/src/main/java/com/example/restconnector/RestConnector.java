package com.example.restconnector;

import com.example.restconnector.model.HttpMethod;
import com.example.restconnector.model.RestRequest;
import com.example.restconnector.model.RestResponse;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Interface defining the contract for REST API connectors.
 * Implementations should handle different authentication methods and connection configurations.
 */
public interface RestConnector {

    /**
     * Executes a REST request and returns the response.
     *
     * @param request The request to execute
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    <T> RestResponse<T> execute(RestRequest request, Class<T> responseType) throws RestConnectorException;

    /**
     * Executes a REST request asynchronously and returns a CompletableFuture for the response.
     *
     * @param request The request to execute
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return A CompletableFuture that will complete with the response
     */
    <T> CompletableFuture<RestResponse<T>> executeAsync(RestRequest request, Class<T> responseType);

    /**
     * Convenience method for making a GET request.
     *
     * @param url The URL to send the request to
     * @param headers Optional headers to include in the request
     * @param queryParams Optional query parameters to include in the request URL
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    default <T> RestResponse<T> get(String url, Map<String, String> headers, Map<String, String> queryParams, Class<T> responseType) throws RestConnectorException {
        RestRequest request = RestRequest.builder()
                .url(url)
                .method(HttpMethod.GET)
                .headers(headers)
                .queryParams(queryParams)
                .build();
        return execute(request, responseType);
    }

    /**
     * Convenience method for making a POST request.
     *
     * @param url The URL to send the request to
     * @param body The request body
     * @param headers Optional headers to include in the request
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    default <T> RestResponse<T> post(String url, Object body, Map<String, String> headers, Class<T> responseType) throws RestConnectorException {
        RestRequest request = RestRequest.builder()
                .url(url)
                .method(HttpMethod.POST)
                .headers(headers)
                .body(body)
                .build();
        return execute(request, responseType);
    }

    /**
     * Convenience method for making a PUT request.
     *
     * @param url The URL to send the request to
     * @param body The request body
     * @param headers Optional headers to include in the request
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    default <T> RestResponse<T> put(String url, Object body, Map<String, String> headers, Class<T> responseType) throws RestConnectorException {
        RestRequest request = RestRequest.builder()
                .url(url)
                .method(HttpMethod.PUT)
                .headers(headers)
                .body(body)
                .build();
        return execute(request, responseType);
    }

    /**
     * Convenience method for making a DELETE request.
     *
     * @param url The URL to send the request to
     * @param headers Optional headers to include in the request
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    default <T> RestResponse<T> delete(String url, Map<String, String> headers, Class<T> responseType) throws RestConnectorException {
        RestRequest request = RestRequest.builder()
                .url(url)
                .method(HttpMethod.DELETE)
                .headers(headers)
                .build();
        return execute(request, responseType);
    }

    /**
     * Convenience method for making a PATCH request.
     *
     * @param url The URL to send the request to
     * @param body The request body
     * @param headers Optional headers to include in the request
     * @param responseType The class of the expected response body
     * @param <T> The type of the response body
     * @return The response from the REST API
     * @throws RestConnectorException if an error occurs during the request
     */
    default <T> RestResponse<T> patch(String url, Object body, Map<String, String> headers, Class<T> responseType) throws RestConnectorException {
        RestRequest request = RestRequest.builder()
                .url(url)
                .method(HttpMethod.PATCH)
                .headers(headers)
                .body(body)
                .build();
        return execute(request, responseType);
    }
}