package com.example.restconnector.auth;

import com.example.restconnector.model.RestRequest;

/**
 * Interface for authentication strategies used by the REST connector.
 * Different implementations will handle various authentication methods like Basic, OAuth, SSL, mTLS, etc.
 */
public interface AuthenticationStrategy {

    /**
     * Applies authentication to the given request.
     * This might involve adding headers, modifying the URL, or configuring SSL/TLS settings.
     *
     * @param request The request to authenticate
     * @return The authenticated request (may be the same instance with modifications)
     */
    RestRequest authenticate(RestRequest request);
    
    /**
     * Gets the name of this authentication strategy.
     *
     * @return The name of the authentication strategy
     */
    String getName();
    
    /**
     * Checks if this authentication strategy requires SSL/TLS.
     *
     * @return true if SSL/TLS is required, false otherwise
     */
    boolean requiresSecureConnection();
}